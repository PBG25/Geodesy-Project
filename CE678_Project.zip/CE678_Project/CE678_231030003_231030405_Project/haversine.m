% Define a function to calculate the Haversine distance between two points
function d = haversine(lat_1, long_1, lat_2, long_2)


    R = 6371; % Radius of the Earth in kilometers

    % Calculate the differences in latitude and longitude
    dlat = deg2rad(lat_2 - lat_1);
    dlong = deg2rad(long_2 - long_1);

     % Haversine formula
    a = sin(dlat/2)^2 + cos(deg2rad(lat_1)) * cos(deg2rad(lat_2)) * sin(dlong/2)^2;
    c = 2 * atan2(sqrt(a), sqrt(1-a));
    % Calculate the spherical distance
    d = R * c;
end



% Example usage
% Coordinates for two points (latitude, longitude) in decimal degrees
%lat_1 = 37.7749;
%long_1 = -122.4194;

%lat_2 = 34.0522;
%long_2 = -118.2437;

% Calculate the Haversine distance
%distance = haversine(lat_1, long_1, lat_2, long_2);


