function [hav_dist, azimuth]=dist_azi(rad,lon_1,lon_2,lat_1,lat_2)
    % Reference
    % https://in.mathworks.com/matlabcentral/fileexchange/27785-distance-calculation-using-haversine-formula

    % difference in latitude and longitude_
    delLat=lat_2-lat_1; % latidue
    delLong=lon_2-lon_1; % longitude

    hvf=sin((delLat)./2).^2 + cos(lat_1).*cos(lat_2) .* sin(delLong./2).^2; % haversine formula
    arc=2.*atan2(sqrt(hvf),sqrt(1-hvf));
    %Haversine distance
    hav_dist=rad.*arc;  % spherical distance betweeen two points

    % AZIMUTH Formula from the project sheet provided to us
    % Azimuth calculation using latitude and longitude information
    numerator=cos(lat_2) .* sin(lon_2-lon_1);
    denominator=cos(lat_1).*sin(lat_2)-(sin(lat_1).*cos(lat_2).*cos(lon_2-lon_1));
    azimuth=atan(numerator./denominator);
end


% example
% Example usage of the dist_azi function

% Given coordinates for two points (latitude, longitude) in decimal degrees
%lat1 = 37.7749;
%lon1 = -122.4194;

%lat2 = 34.0522;
%lon2 = -118.2437;

% Earth radius in kilometers
%earth_radius = 6371;

% Calculate Haversine distance and azimuth
%[haversine_distance, azimuth_angle] = dist_azi(earth_radius, lon1, lon2, lat1, lat2);


