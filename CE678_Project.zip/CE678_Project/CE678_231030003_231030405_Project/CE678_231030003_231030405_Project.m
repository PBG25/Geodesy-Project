clc
clear
warning("off", "all");


% loading necessary packages
pkg load statistics;
%pkg load mapping;
pkg load netcdf;

% In this project we are going to calculate gravity anomaly values in the study
% region 14 degree latitude to 20 degree latitude and 63 degree latitude to 69
% degree latitude

% Step followed
% 1. extracting data
% 2. SSH heights
% 3. Along track data
% 4. DOV components
% 5. Kringing interpolation
% 6. FFT of DOV components
% 7. Inverse FFT for Gravity anomaly


%% untaring the data

% untar('007573_saral_f_ssh_40.tar.gz');
% its a one time process. Its like unzipping the file to extract more file


%%  Displaying meta data

% Displaying metadata from one of the file  for Cycle 35 Pass 0511
% Discribing genteral path to get the file location
path='C:/Users/prave/Desktop/Project work/Project/SARAL/035/035_0511ssh.40.nc';
ncdisp(path)

%%  Extracting data from all cycles

% Defining variable that we have to extract from each file
ncvars =  {'ssh.40', 'glat.00', 'glon.00'};

% defining pases to create a address ssh, latitude  and longitude
file={'0053','0096','0167','0182','0253','0268','0339','0354','0425','0440','0511','0625','0640','0711','0726','797','812','0883','0898','0969','984'};

% defining the cell size (Max cycle: 35 & Passes: 21 (including ascending and descending passes) ) for the latidtude, longitude and SSH
latitude = cell(21,35);
longitude = cell(21,35);
ssh = cell(21,35);

for i=1:35
    for j=1:21
        projectdir = 'C:/Users/prave/Desktop/Project work/Project/SARAL/00';
        n=int2str(i);
        m=int2str(j);
        projectdir=strcat(projectdir,n,'\','00',num2str(n),'_',file{j},'ssh.40.nc');

        if isfile(projectdir)==1
            ssh{j,i} = ncread(projectdir, 'ssh.40');
            latitude{j,i}=ncread(projectdir,'glat.00');
            longitude{j,i}=ncread(projectdir,'glon.00');
        else
                ssh{j,i} = {};
                latitude{j,i}={};
                longitude{j,i}={};
        end
    end

    if i>9
        for j=1:21
                projectdir = 'C:/Users/prave/Desktop/Project work/Project/SARAL/0';
                n=int2str(i);
                m=int2str(j);
                projectdir=strcat(projectdir,n,'\','0',num2str(n),'_',file{j},'ssh.40.nc');

                if isfile(projectdir)==1
                    ssh{j,i} = ncread(projectdir, 'ssh.40');
                    latitude{j,i}=ncread(projectdir,'glat.00');
                    longitude{j,i}=ncread(projectdir,'glon.00');
                else
                    ssh{j,i} = {};
                    latitude{j,i}={};
                    longitude{j,i}={};
                end
        end
     end
end

% Selecting ascending passes for the computation
% defining file name for ascending passes
passes = [0969, 0912, 0726,0640, 0511, 0425, 0268, 0182, 0096];
% indexing the file
pass_indices = [20,18,14,11,9,7,5,3,1];

% Initialize arrays for SSH, latitude, and longitude for all passes to extract all data
num_passes = length(passes);

ssh_data = cell(1, num_passes);    % ssh data
lat_data = cell(1, num_passes);    % latitude data
lon_data = cell(1, num_passes);    % longitude data

for pass_idx = 1:num_passes
    pass_number = pass_indices(pass_idx);

    % Initialize arrays for the specific pass
    ssh_pass = zeros(98, 35);
    lat_pass = zeros(98, 35);
    lon_pass = zeros(98, 35);

    for cycle_idx = 1:35
        if isempty(ssh{pass_number, cycle_idx})
            continue;
        end

        data_size = size(ssh{pass_number, cycle_idx});
        ssh_pass(1:data_size, cycle_idx) = ssh{pass_number, cycle_idx};
        lat_pass(1:data_size, cycle_idx) = latitude{pass_number, cycle_idx};
        lon_pass(1:data_size, cycle_idx) = longitude{pass_number, cycle_idx};
    end

    % Set zero values to NaN
    ssh_pass(ssh_pass == 0) = NaN;
    lat_pass(lat_pass == 0) = NaN;
    lon_pass(lon_pass == 0) = NaN;

    % Store the data for the current pass
    ssh_data{pass_idx} = ssh_pass;
    lat_data{pass_idx} = lat_pass;
    lon_data{pass_idx} = lon_pass;
end

% Stastical analysis : Finding mean meadian mode , Min Max , Standard deviation

% For cycle 1 pass 0096
Ac96=ssh{2,1}; % change the name of file here to get the statistics of the data
A96=double(Ac96)'; % converting single to double type

% Finding stastical paramters Max, Min Mean Median Mode
stat = [max(A96),min(A96),mean(A96),median(A96),mode(A96)];
fprintf('\nMax = %f\n', stat(1,1));
fprintf('\nMin = %f\n', stat(1,2));
fprintf('\nMean = %f\n', stat(1,3));
fprintf('\nMedian = %f\n', stat(1,4));
fprintf('\nMode = %f\n', stat(1,5));
fprintf('\nThe Median is greater than Mean\n')

% Standard deviation, variance, skewness and kurtosis
spd=[std(A96),skewness(A96),kurtosis(A96)];
fprintf('\nStandard Deviation = %f\n', spd(1,1));
fprintf('\nVariance = %f\n', sqrt(std(A96)));

% plotting fifure of the data
figure('Position',get(0,'ScreenSize'))
nbins = 25;
hist(A96, nbins)
grid on
xlabel('SSH', 'FontWeight', 'bold', 'FontSize', 14)
ylabel('Frequency', 'FontWeight', 'bold', 'FontSize', 14)
title('Histogram Plot', 'FontSize', 16, 'FontWeight', 'bold')

figure('Position',get(0,'ScreenSize'))
histfit(A96)
grid on
xlabel('SSH', 'FontWeight', 'bold', 'FontSize', 14)
ylabel('Frequency', 'FontWeight', 'bold', 'FontSize', 14)
title('HistFit Plot', 'FontSize', 16, 'FontWeight', 'bold')

figure('Position',get(0,'ScreenSize'))
boxplot(A96)
grid on
ylabel("SSH", 'FontWeight', 'bold', 'FontSize', 14)
hold on
plot(1:length(A96), mean(A96), 'dk')
title('Boxplot')

% pre-processing of data taking median SSH values for the calcualtion
% median because it the best way to represent the population

% Initialize cell arrays to store median values
median_ssh = cell(1, length(passes));

for pass_idx = 1:length(passes)
    pass_data = ssh_data{pass_idx};  % Get SSH data for the current pass
    median_ssh{pass_idx} = median(pass_data,2, 'omitnan');
end


%% MDT Model correction for the SSH
% MDT = Mean dynamics topography
%f1 is the path file for mdt_study area data
% displaying metadata
% source : https://data.marine.copernicus.eu/products
f1='mdt.nc';
var=ncinfo(f1);
ncdisp(f1)

%getting the mdt, latitude and longitude values from the above mdt_model.nc file
lat_mdt=ncread(f1, 'latitude');
long_mdt=ncread(f1, 'longitude');
mdt_1=ncread(f1, 'mdt');
mdt = mdt_1(:,:,1);

% Plotting the data
figure('Position', [0 0 1900 980]);
imagesc(long_mdt', lat_mdt, mdt)
hold on
title('Mean Dynamic Topographic Model','FontSize',16,'FontWeight','bold')
xlabel('Longitude','FontWeight','bold','FontSize',14)
ylabel('Latitude','FontWeight','bold','FontSize',14)
colorbar('Title', 'm','Fontsize', 16);
daspect([1,1,1])

% over lapping it with passes
plot(lon_data{1}(:, 1),lat_data{1}(:, 1),'r','LineWidth', 2)
hold on
plot(lon_data{2}(:, 1),lat_data{2}(:, 1),'g','LineWidth', 2)
hold on
plot(lon_data{3}(:, 1),lat_data{3}(:, 1),'b','LineWidth', 2)
hold on
plot(lon_data{4}(:, 1),lat_data{4}(:, 1),'c','LineWidth', 2)
hold on
plot(lon_data{5}(:, 1),lat_data{5}(:, 1),'m','LineWidth', 2)
hold on
plot(lon_data{6}(:, 1),lat_data{6}(:, 1),'y','LineWidth', 2)
hold on
plot(lon_data{7}(:, 1),lat_data{7}(:, 1),'k','LineWidth', 2)
hold on
plot(lon_data{8}(:, 1),lat_data{8}(:, 1),'r','LineWidth', 2)
hold on
plot(lon_data{9}(:, 1),lat_data{9}(:, 1),'g','LineWidth', 2)
legend('Pass0096','Pass0182','Pass0268','Pass0425','Pass0511','Pass0640','Pass0726','Pass0912','Pass0969')
legend('Location','northeastoutside')
set(gca, 'FontSize', 16)
print('my_plot.png', '-dpng');
daspect([1,1,1])
hold off


%% median value of dynamic topography model data
mdt_median=median(mdt,'all');
imagesc(long_mdt, lat_mdt, mdt')

% so this m_mdt value will be subtracted from all the SSH observations to
% get the SSH that are corrected for dynamic topography
a=  median_ssh{1}(:,1);
b=  median_ssh{2}(:,1);
c = median_ssh{3}(:,1);
d = median_ssh{4}(:,1);
e = median_ssh{5}([1:98],1);
f = median_ssh{6}(:,1);
g = median_ssh{7}(:,1);
h = median_ssh{8}(:,1);
i = median_ssh{9}(:,1);

ssh_median=[a,b,c,d,e,f,g,h,i];
%ssh_cr = ssh_m;
% substracting Sea surface height from mean dynamic topography
ssh_bar=ssh_median-mdt_median;

hold on
title('SSH - MDT','FontSize',16,'FontWeight','bold')
xlabel('Longitude','FontWeight','bold','FontSize',14)
ylabel('Latitude','FontWeight','bold','FontSize',14)
colorbar('Title', 'm','Fontsize', 16);
set(gca, 'FontSize', 16)
print('my_plot.png', '-dpng');
daspect([1,1,1])


%% costline for for visualtation of study area

 % plotting the coast lines
figure('Position', [0 0 1900 980]);
load coastlines
plot(coastlon,coastlat,'k')
hold on

% plottings the passes
plot(lon_data{1}(:, 1),lat_data{1}(:, 1),'r','LineWidth', 2)
hold on
plot(lon_data{2}(:, 1),lat_data{2}(:, 1),'g','LineWidth', 2)
hold on
plot(lon_data{3}(:, 1),lat_data{3}(:, 1),'b','LineWidth', 2)
hold on
plot(lon_data{4}(:, 1),lat_data{4}(:, 1),'c','LineWidth', 2)
hold on
plot(lon_data{5}(:, 1),lat_data{5}(:, 1),'m','LineWidth', 2)
hold on
plot(lon_data{6}(:, 1),lat_data{6}(:, 1),'y','LineWidth', 2)
hold on
plot(lon_data{7}(:, 1),lat_data{7}(:, 1),'k','LineWidth', 2)
hold on
plot(lon_data{8}(:, 1),lat_data{8}(:, 1),'r','LineWidth', 2)
hold on
plot(lon_data{9}(:, 1),lat_data{9}(:, 1),'g','LineWidth', 2)
xlabel('Longitude','FontSize',16,'FontWeight','bold')
ylabel('Latitude','FontSize',16,'FontWeight','bold')
title('Satellite track passes','FontSize',16,'FontWeight','bold')
legend('coastlines','Pass0096','Pass0182','Pass0268','Pass0425','Pass0511','Pass0640','Pass0726','Pass0912','Pass0969')
legend('Location', 'northeastoutside');
xlim([50 90])
ylim([0 30])
set(gca, 'FontSize', 16)
print('my_plot.png', '-dpng');
daspect([1,1,1])


%% Plotting the passes on the mesh grid for visualization

figure('Position', [0 0 1900 980]);
x=63:0.25:69; % longitude variation
y=14:0.25:20; % latitude variation
[X, Y]=meshgrid(x,y); %meshgrid
plot(X,Y,'k',X',Y','k')
hold on

plot(lon_data{1}(:, 1),lat_data{1}(:, 1),'r','LineWidth', 2)
hold on
plot(lon_data{2}(:, 1),lat_data{2}(:, 1),'g','LineWidth', 2)
hold on
plot(lon_data{3}(:, 1),lat_data{3}(:, 1),'b','LineWidth', 2)
hold on
plot(lon_data{4}(:, 1),lat_data{4}(:, 1),'c','LineWidth', 2)
hold on
plot(lon_data{5}(:, 1),lat_data{5}(:, 1),'m','LineWidth', 2)
hold on
plot(lon_data{6}(:, 1),lat_data{6}(:, 1),'y','LineWidth', 2)
hold on
plot(lon_data{7}(:, 1),lat_data{7}(:, 1),'k','LineWidth', 2)
hold on
plot(lon_data{8}(:, 1),lat_data{8}(:, 1),'r','LineWidth', 2)
hold on
plot(lon_data{9}(:, 1),lat_data{9}(:, 1),'g','LineWidth', 2)
xlabel('Longitude','FontSize',16,'FontWeight','bold')
ylabel('Latitude','FontWeight','bold','FontSize',16)
title('Grid visualization for calculating DOV components','FontSize',16,'FontWeight','bold')
set(gca, 'FontSize', 16)
legend('Pass0096','Pass0182','Pass0268','Pass0425','Pass0511','Pass0640','Pass0726','Pass0912','Pass0969')
legend('Location', 'northeastoutside');
set(gca, 'FontSize', 16)
print('my_plot.png', '-dpng');
daspect([1,1,1])

% computing the spherical distance and azimuth for one values to test the function
% source : https://in.mathworks.com/matlabcentral/fileexchange/38812-latlon-distance

% check the function by test values
rad=6371;                  % radius of earth
longlat1=[-43 172]*pi/180; % converted to radians
longlat2=[-44  171]*pi/180;%  converted to radians

lat_1=longlat1(1);% Extracting first latitude values
lat_2=longlat2(1);% Extracting second latitude values
lon_1=longlat1(2);% Extracting first longitude values
lon_2=longlat2(2);% Extracting second longitude values


% function to calculate azimuth and spherical distance
[hvd, azim]=dist_azi(rad,lon_1,lon_2,lat_1,lat_2);
fprintf("\nSpherical distance: - %f\n", hvd)
fprintf("\nAzimuth: - %f\n", azim)


lat_cr = [lat_data{1}(:,1),lat_data{2}(:,1),lat_data{3}(:,1),lat_data{4}(:,1),lat_data{5}([1:98],1),lat_data{6}(:,1),lat_data{7}(:,1),lat_data{8}(:,1),lat_data{9}(:,1)];
long_cr = [lon_data{1}(:,1),lon_data{2}(:,1),lon_data{3}(:,1),lon_data{4}(:,1),lon_data{5}([1:98],1),lon_data{6}(:,1),lon_data{7}(:,1),lon_data{8}(:,1),lon_data{9}(:,1)];

%% Final Sea Surface Height (SSH), latitude and longitude values

ssh_f=ssh_bar;
lat_f=lat_cr;
long_f=long_cr;

%% Computing of DOV: (delta N/ delta S): d-N/d-s

% d-N/d-s will be stored in slope array
% Define a function to calculate the spherical distance distance between two points

% Initialize the slope array
slope = zeros(length(ssh_bar) - 1, 9);
delN = zeros(length(ssh_bar) - 1, 9);  % Initialize del_N array
delS = zeros(length(ssh_bar) - 1, 9); % Initialize del_S array

for i = 1:9
    for j = 1:length(ssh_bar) - 1
        delN(j, i) = ssh_bar(j + 1,i) - ssh_bar(j,i); % Numerator of slope calculation

        % Calculate the distance using the Haversine formula
        lat1 = lat_cr(j, i);
        lat2 = lat_cr(j + 1, i);
        lon1 = long_cr(j, i);
        lon2 = long_cr(j + 1, i);
        dist = haversine(lat1, lon1, lat2, lon2); % Denominator for slope calcualtion

        delS(j, i) = dist;
    end
end

slope = delN ./ delS;
% Slope information stored in slope array for all satellite passes from 1 to 9

% degining mesh grid for latitude and longitude extent
figure('Position', [0 0 1900 980]);
y=63:0.25:69;                 % longitude extent
x=14:0.25:20;                 % latitude extent
[X, Y]=meshgrid(x,y);         %meshgrid
plot(X,Y,X',Y')

% defining an empty cell for all the variables
Cell = cell (24,24);
c_azim=cell(24,24);
c_sp_d=cell(24,24);
dov_EW=cell(24,24);
dov_NS=cell(24,24);
A=cell(24,24);
Slope_Paramters=cell(24,24);
P = cell(24,24);
A_bar1=cell(24,24);
slope = cell(24,24);

idd={};                   % defining empty cell to store the values
for jj=1:9                % for 9 passes for SSH values
for i=1:(length(x)-1)     % passing through long values
    for j=1:(length(y)-1) % passing through lat value

        % extracting data each pass
        lat_cell =lat_cr(:,jj);
        long_cell =long_cr(:,jj);
        ssh_cell=ssh_bar(:,jj);

        %  grid cell
        xi=[X(i,j) Y(i,j)];
        yi=[X(i+1,j+1) Y(i+1,j+1)];

        % computing grid centre
        x_centre=(xi(1)+yi(1))/2;
        y_centre=(xi(2)+yi(2))/2;
        A_centre=[x_centre, y_centre];

        A_bar1{i,j}=x_centre;


        % finding respective data on the grid
        idx=find(lat_cell>=xi(1) & lat_cell<yi(1));
        idy=find(long_cell>=xi(2) & long_cell<yi(2));
        ind=intersect(idx,idy);

        % index the cells
        lat_ind{jj,i,j}=lat_cell(ind);
        long_ind{jj,i,j}=long_cell(ind);
        ssh_ind{jj,i,j}=ssh_cell(ind);
        delS1 {jj,i,j} = delS(ind);
        P_mat{jj,i,j}=[long_cell(ind), lat_cell(ind),ssh_cell(ind),delS(ind)];

        if not(isempty(P_mat{jj,i,j}))
            Cell{i,j}  = P_mat{jj,i,j};

            slope{i,j} = Cell{i,j}(:,3) ./Cell{i,j}(:,4);
        end

        if not(isempty(Cell{i,j}))
            rad=6371;                                       % radius of earth
            longlat1=[Cell{i,j}(:,1) Cell{i,j}(:,2)]*pi/180 ;% lat and long converted to radians
            longlat2=[A_centre(1) A_centre(2)]*pi/180 ;% lat and long converted to radians
            lat_1=longlat1(:,1); % First lat value
            lat_2=longlat2(:,2); % Second lat value

            %call function to compute azimuth and spherical distance
            [sp_dist, azimuth]=dist_azi(rad,longlat1(:,1),longlat1(:,2),lat_1,lat_2);
            c_sp_d{i,j}=sp_dist;
            c_azim{i,j}=azimuth;

            % weight matrix
            P{i,j}=diag(1./c_sp_d{i,j});


             % design matrix
            A{i,j} = [cos(c_azim{i,j}) sin(c_azim{i,j})];

            % using least square approximation for the paramter finding
            Slope_Paramters{i,j}=inv(double([A{i,j}(:,1) A{i,j}(:,2)]' * P{i,j} * [A{i,j}(:,1) A{i,j}(:,2)]))' * ([A{i,j}(:,1) A{i,j}(:,2)]' * P{i,j} * slope{i,j}(:));
        end
    end
end
end


%% DOV components (\eta and \xi)
%are stored in Slope paramters variables from the above section
% Slope paramters as there are two paramteters seperating the two parameters

DoVNS=cell(24,24); % empty cell to store onle one DOV components
for i =1: 24
    for j=1:24
       if not(isempty(Slope_Paramters{i,j}))
            DoVNS{i,j}=Slope_Paramters{i,j}(1,:);
        end
    end
end

%
DoVEW=cell(24,24); % empty cell to store onle one DOV components
for i =1: 24
    for j=1:24
       if not(isempty(Slope_Paramters{i,j}))
            DoVEW{i,j}=Slope_Paramters{i,j}(2,:);
        end
    end
end

%% Assigning the empty cell in both DOV components to zero

for i = 1:24
    for j=1:24

        if isempty(DoVNS{i,j})
            DoVNS{i,j} = NaN;
        end
    end
end

DoVNS_1= cell2mat(DoVNS);

for i = 1:24
    for j=1:24

        if isempty(DoVEW{i,j})
            DoVEW{i,j} = NaN;
        end
    end
end



%% DOV components visulaization
% NS component
% visualization of data
figure('Position',get(0,'ScreenSize'))
DoVNS_1=cell2mat(DoVNS); % converting the cell to matrix
DoVNS_1 = DoVNS_1./1000;
imagesc(y,x,DoVNS_1') % imagesc for visualization
colorbar('Title', 'mRad','Fontsize', 12);
ylabel('Latitude','FontSize',14,'FontWeight','bold')
xlabel('Longitude','FontSize',14,'FontWeight','bold')
title('NS Components')

e=mean(DoVNS_1,'all');
DVNS_1(DoVNS_1==0) = e;
set(gca, 'FontSize', 16)
daspect([1,1,1])
print('my_plot.png', '-dpng');

% scatter plot for Non NaN values
% Find the non-NaN values and their coordinates
[x_nonnan, y_nonnan] = find(~isnan(DoVNS_1));
%Create a scatter plot with circles for non-NaN values
figure('Position',get(0,'ScreenSize'))
scatter(x_nonnan, y_nonnan, 100, 'filled', 'b', 'o');  % You can adjust the marker size and color
%Add labels
xlabel('Grid point along X', 'FontSize', 14);
ylabel('Grid point along Y', 'FontSize', 14);
title('Available DOV')
legend('Available DOV Values', 'Available DOV Values', 'FontSize', 12, 'Location', 'northeastoutside');
daspect([1,1,1])

% scatter plot for NaN values
% Find the NaN values and their coordinates
[x_nan, y_nan] = find(isnan(DoVNS_1));
% Create a scatter plot with circles for NaN values
figure('Position',get(0,'ScreenSize'))
scatter(x_nan, y_nan, 100, 'filled', 'r', 's');  % You can adjust the marker size and color
% Add labels
xlabel('Grid point along X', 'FontSize', 14);
ylabel('Grid point along Y', 'FontSize', 14);
title('Non-Available DOV')
% Add a legend to distinguish between non-NaN and NaN values
legend('NaN Values', 'NaN Values', 'FontSize', 12, 'Location', 'northeastoutside');
daspect([1, 1, 1]);


% EW component
% visualization of data
figure('Position',get(0,'ScreenSize'))
DoVEW_1=cell2mat(DoVEW);
DoVEW_1 = DoVEW_1./1000;
imagesc(y,x,DoVEW_1')
colorbar('Title', 'mRad','Fontsize', 12);
ylabel('Latitude','FontSize',14,'FontWeight','bold')
xlabel('Longitude','FontSize',14,'FontWeight','bold')
title('EW Components')
%DV_EW1(DV_EW1==0) = NaN;
d=mean(DoVEW_1,'all');
DV_EW1(DoVEW_1==0) = d;
set(gca, 'FontSize', 16)
print('my_plot.png', '-dpng');
daspect([1,1,1])

%% Kriging interpolation
% interpolation for north south component
NS = DoVNS_1;
% Generate the grid coordinates
[X, Y] = meshgrid(1:24, 1:24);

% Find the coordinates and values of known data points (non-NaN values)
x_known = X(~isnan(NS));
y_known = Y(~isnan(NS));
values_known = NS(~isnan(NS));

% Create a grid for interpolation
[Xq, Yq] = meshgrid(1:1:24, 1:1:24);  % Define grid resolution

% Perform interpolation using griddata
interpolated_matrix_NS = griddata(x_known, y_known, values_known, Xq, Yq);
 y = 63:0.25:69;          % longitude variation
 x = 14:0.25:20;            % latitude variation
% Display the interpolated matrix
d_mean=mean(interpolated_matrix_NS,'omitnan');
d_col = mean(d_mean);
interpolated_matrix_NS(isnan(interpolated_matrix_NS)) = d_col;
figure("position",get(0,"screensize"))
imagesc(y,x,interpolated_matrix_NS');      % visualization after interpolation
colorbar('Title', 'mRad','Fontsize', 12);
title('Interpolation Result NS components');
xlabel('Longitude', 'FontSize', 14);
ylabel('Latitude', 'FontSize', 14);
colormap('jet');
daspect([1,1,1])


% Kriging interpolation gor EW component
EW = DoVEW_1;
% Generate the grid coordinates
[X, Y] = meshgrid(1:24, 1:24);

% Find the coordinates and values of known data points (non-NaN values)
x_known = X(~isnan(EW));
y_known = Y(~isnan(EW));
values_known = EW(~isnan(EW));

% Create a grid for interpolation
[Xq, Yq] = meshgrid(1:1:24, 1:1:24);  % Define grid resolution

% Perform interpolation using griddata
interpolated_matrix_EW = griddata(x_known, y_known, values_known, Xq, Yq);
 y = 63:0.25:69;          % longitude variation
 x = 14:0.25:20;            % latitude variation
 %Display the interpolated matrix
d_mean=mean(interpolated_matrix_EW,'omitnan');
d_col = mean(d_mean);
interpolated_matrix_EW(isnan(interpolated_matrix_EW)) = d_col;
figure("position",get(0,"screensize"))
imagesc(y,x,interpolated_matrix_EW');       % visualization after interpolation
colorbar('Title', 'mRad','Fontsize', 12);
title('Interpolation Result EW Componenet');
xlabel('Longitude', 'FontSize', 14);
ylabel('Latitude', 'FontSize', 14);
colormap('jet');
daspect([1,1,1])

%% FFT for DOV components
% Perform FFT NS component
figure("position",get(0,"screensize"))
fft_NS = fft(interpolated_matrix_NS);    %fft for NS interpolated data
fft_NS = abs(fft_NS);
imagesc(y,x,fft_NS')
xlabel('Grid point along X', 'FontSize', 14);
ylabel('Grid point along Y', 'FontSize', 14);
%title('FFT DOV NS component')
%imagesc(log(1 + fft_NS)); % Use log for better visualization
% Add labels and title
colormap('jet');
title('FFT DOV NS component');
daspect([1,1,1])


% Perform FFT EW components
figure("position",get(0,"screensize"))
fft_EW = fft(interpolated_matrix_EW);    % fft for EW interpolated data
fft_EW = abs(fft_EW);
imagesc(y,x,fft_EW' )
xlabel('Grid point along X', 'FontSize', 14);
ylabel('Grid point along Y', 'FontSize', 14);
title('FFT DOV EW component')
%imagesc(log(1 + fft_EW)); % Use log for better visualization
colormap('jet');
daspect([1,1,1])

%% Normal Gravity Calculation
ngravity=cell(24,24); % normal gravity
for i=1:24
    for j=1:24
        ngravity{i,j}=ngrav(cell2mat(A_bar1(i,j)));
    end
end
ngravity=cell2mat(ngravity);

% Visualization of Normal Gravity Data
figure('Position',get(0,'ScreenSize'))
ngrav_mean=mean(ngravity);
ngrav_median=median(ngravity);
ngrav_mode=mode(ngravity);
imagesc(x,y,ngravity')
xlabel('Grid point along X', 'FontSize', 14);
ylabel('Grid point along Y', 'FontSize', 14);
colorbar('Title', 'm/s^2','Fontsize', 16);
title('Normal Gravity Variation along the grid')
set(gca, 'FontSize', 16)
print('my_plot.png', '-dpng');
daspect([1,1,1])

% Histogram for normal gravity
figure('Position',get(0,'ScreenSize'))
hist(ngravity)
xlabel('Normal Gravity m/s^2','FontSize',14,'FontWeight','bold')
ylabel('Frequency','FontSize',14,'FontWeight','bold')
title('Normal Gravity Variations')
grid on
%set(gca, 'FontSize', 16)
%print('my_plot.png', '-dpng');


%% Inverse FFT
% Calculating gravity anomaly by using applying INVERSE FFT
% kx , ky = wave number
% kx=1/6; ky=1/6; k=sqrt(kx^2+ky^2);
figure('Position',get(0,'ScreenSize'))
DV_fft=ngravity.*(fft_NS+fft_EW);             % combining DOV FFT
DV_fft_im=(0-1i)*DV_fft;                      % considering only real values
gravity_anomaly =abs(ifft(DV_fft_im));        % inverse fft for gravity anomaly
%imagesc(log(1 + grav_anom'))
imagesc(y,x,gravity_anomaly')                 % plotting
% Set the colormap to blue
colormap('jet');
colorbar('Title', 'mGal','Fontsize', 12);
xlabel('Grid point along X', 'FontSize', 14);
ylabel('Grid point along Y', 'FontSize', 14);
title('Gravity Anomaly')
daspect([1,1,1])

% plotting the histogram to see the data distributation
figure('Position',get(0,'ScreenSize'))
nbins = 25;
hist(gravity_anomaly, nbins)
grid on
xlabel('Gravity Anomaly', 'FontWeight', 'bold', 'FontSize', 14)
ylabel('Frequency', 'FontWeight', 'bold', 'FontSize', 14)
title('Gravity Anomaly Histogram', 'FontSize', 16, 'FontWeight', 'bold')
print('my_plot.png', '-dpng');

% plotting box plot to see the mean and the out liers
figure('Position',get(0,'ScreenSize'))
boxplot(gravity_anomaly)
grid on
ylabel("SSH", 'FontWeight', 'bold', 'FontSize', 14)
hold on
plot(1:length(gravity_anomaly), mean(gravity_anomaly), 'dk')
title('Boxplot')

