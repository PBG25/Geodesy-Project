pkg load mapping  # Load the mapping package

fid = fopen('mdtp_t1.grd', 'rb');  % Open the file in binary mode
if fid == -1
    error('Failed to open the file.');
end

header = fread(fid, 4, 'char');
ncols = fread(fid, 1, 'int32');
nrows = fread(fid, 1, 'int32');
xllcorner = fread(fid, 1, 'float32');
yllcorner = fread(fid, 1, 'float32');
cellsize = fread(fid, 1, 'float32');
NODATA_value = fread(fid, 1, 'float32');

% Read the data into a matrix
data = fread(fid, [ncols, nrows], 'float32');

fclose(fid);

% Now, 'data' contains the data from the .GRD file, and you can work with it in Octave.



